// file      : odb/oracle/simple-object-statements.cxx
// copyright : Copyright (c) 2005-2015 Code Synthesis Tools CC
// license   : ODB NCUEL; see accompanying LICENSE file

#include <odb/oracle/simple-object-statements.hxx>

namespace odb
{
  namespace oracle
  {
    object_statements_base::
    ~object_statements_base ()
    {
    }
  }
}
