// file      : odb/oracle/prepared-query.cxx
// copyright : Copyright (c) 2005-2015 Code Synthesis Tools CC
// license   : ODB NCUEL; see accompanying LICENSE file

#include <odb/oracle/prepared-query.hxx>

namespace odb
{
  namespace oracle
  {
    prepared_query_impl::
    ~prepared_query_impl ()
    {
    }
  }
}
